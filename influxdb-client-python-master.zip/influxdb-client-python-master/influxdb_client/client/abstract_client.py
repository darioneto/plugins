

class AbstractClient:
    pass